export { default as Section } from "./Section"
export { default as Hero } from "./Hero"
export { default as Testimonial } from "./Testimonial";
export { default as Footer } from "../../Footer";