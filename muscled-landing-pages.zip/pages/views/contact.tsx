import * as React from 'react'
import { NextPage } from 'next'

const Contact: NextPage = () => {
  return <div>This is contact page</div>
}

export default Contact
