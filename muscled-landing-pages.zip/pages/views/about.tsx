import * as React from 'react'
import { NextPage } from 'next'

const Page: NextPage = () => {
  return <div>This is about Page!</div>
}

export default Page
