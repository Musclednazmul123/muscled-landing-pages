declare module "*.svg?inline" {
    const content: any;
    export default content;
  }

declare module '*.png'